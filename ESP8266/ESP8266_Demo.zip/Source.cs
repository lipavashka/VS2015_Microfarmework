See 'usage' tab for code example
Source code for libs is here : https://github.com/MoleculeDotNet/Molecules