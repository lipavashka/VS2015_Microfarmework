Use Nuget (with Include Prerelease enabled) for v2.0.0-beta of one or more of:
   PervasiveDigital.ESP8266
    PervasiveDigital.Net
    PervasiveDigital.Net.Azure.MobileServices
    PervasiveDigital.Net.Azure.Storage
    PervasiveDigital.Security.ManagedProviders
    PervasiveDigital.Utility
    IngenuityMicro.Neon
    IngenuityMicro.Net
Also available as source from : https://github.com/DotNetOpenAutomation/serialwifi