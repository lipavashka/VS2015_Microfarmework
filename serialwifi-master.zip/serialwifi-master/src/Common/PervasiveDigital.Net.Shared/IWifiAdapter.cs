using System;
using Microsoft.SPOT;

namespace PervasiveDigital.Net
{
    public interface IWifiAdapter : INetworkAdapter
    {
    }
}
