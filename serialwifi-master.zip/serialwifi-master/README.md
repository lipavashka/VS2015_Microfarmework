# serialwifi
.Net Support for serial Wifi devices like the ESP8266
